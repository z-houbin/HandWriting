package com.example.handwriting.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.RegionIterator;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.example.handwriting.util.WritingUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HandwritingView extends View {
    private Paint mOutlinePaint, mFillPaint, mTouchPaint, mGridPaint, mDashPaint;
    private List<List<Point>> mFrameData = new ArrayList<>();
    private List<List<Point>> mFillData = new ArrayList<>();
    private Path path = new Path();
    //控件宽高
    private int width = 0, height = 0;
    //当前绘制笔画数
    private int mStrokeStep = 1;
    //单笔最大填充数
    private int mFillMaxStep;
    //动画延迟时间
    private int mDrawDelay = 50;

    private Bitmap touchBitmap;

    private Canvas touchCanvas;


    private int regionIndex = 0;

    private boolean inTouch = false;
    //不规则范围
    private List<Region> regionList = new ArrayList<>();
    //已经画完的笔画
    private List<Integer> drawFinishStorke = new ArrayList<>();

    public HandwritingView(Context context) {
        super(context);
        init();
    }

    public HandwritingView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public HandwritingView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        mOutlinePaint = new Paint();
        mOutlinePaint.setColor(Color.GRAY);
        mOutlinePaint.setStrokeJoin(Paint.Join.ROUND);
        mOutlinePaint.setStrokeCap(Paint.Cap.ROUND);
        mOutlinePaint.setAntiAlias(true);
        //Paint.Style.FILL_AND_STROKE 为实心
        mOutlinePaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mOutlinePaint.setStrokeWidth(15);

        mFillPaint = new Paint();
        mFillPaint.setColor(Color.RED);
        mFillPaint.setStrokeJoin(Paint.Join.ROUND);
        mFillPaint.setStrokeCap(Paint.Cap.ROUND);
        mFillPaint.setAntiAlias(true);
        mFillPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mFillPaint.setStrokeWidth(10);

        mTouchPaint = new Paint();
        mTouchPaint.setColor(Color.BLUE);
        mTouchPaint.setAntiAlias(true);
        mTouchPaint.setStyle(Paint.Style.FILL);
        //mTouchPaint.setStrokeWidth(2);

        mGridPaint = new Paint();
        mGridPaint.setColor(Color.BLACK);
        mGridPaint.setAntiAlias(true);
        mGridPaint.setStyle(Paint.Style.STROKE);
        mGridPaint.setStrokeWidth(4);

        mDashPaint = new Paint();
        mDashPaint.setColor(Color.DKGRAY);
        mDashPaint.setAntiAlias(true);
        mDashPaint.setStyle(Paint.Style.STROKE);
        mDashPaint.setStrokeWidth(4);
        mDashPaint.setPathEffect(new DashPathEffect(new float[]{5, 5}, 0));

        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    //当前进度
    private int stepIdx = 0;
    //步进长度
    private int step = 20;

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        width = getMeasuredWidth();
        height = getMeasuredHeight();

        WritingUtil.width = width;
        WritingUtil.height = height;
        if (touchBitmap == null) {
            touchBitmap = Bitmap.createBitmap(getMeasuredWidth(), getMeasuredHeight(), Bitmap.Config.ARGB_8888);
            touchCanvas = new Canvas(touchBitmap);
        }
    }

    /**
     * 设置显示文字
     *
     * @param text
     * @throws Exception
     */
    public void setText(char text) throws Exception {
        drawFinishStorke.clear();
        drawStorke = -1;
        mStrokeStep = 1;
        mFillMaxStep = 10;
        paths.clear();
        regionList.clear();
        //JSON 数据解析
        String assetsName = WritingUtil.urlEncode(String.valueOf(text));
        String jsonData = WritingUtil.getAssestFileContent(getContext(), assetsName);
        mFrameData = WritingUtil.parseJsonFrame(jsonData);
        mFillData = WritingUtil.parseJsonFill(jsonData);
        touchCanvas.drawColor(0, PorterDuff.Mode.CLEAR);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //画田字格
        drawGrid(canvas);
        //画边框背景
        drawOutline(canvas);
        if (regionList.size() == 0) {
            initData();
        }
        //动画
        //fillStroke(canvas);
        canvas.drawBitmap(touchBitmap, 0, 0, mTouchPaint);
    }

    private Path touchPath = new Path();
    private float touchX, touchY;

    private List<Path> paths = new ArrayList<>();

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX(), y = event.getY();
        touchX = event.getX();
        touchY = event.getY();

        int stroke = -2;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                touchPath.reset();
                touchPath.moveTo(x, y);
                break;
            case MotionEvent.ACTION_MOVE:
                inTouch = true;
                touchPath.lineTo(x, y);
                stroke = isInsideStroke(touchPath);
                //stroke = isInsideStroke(new Point((int) touchX, (int) touchY));
                System.out.println("当前触摸笔画 ---- >" + stroke);
                //防止越过正确笔顺
                if (drawStorke + 1 == stroke) {
                    //下一笔
                    drawStorke = stroke;
                    drawStep();
                } else if (drawStorke == stroke) {
                    //当前正在绘制的笔画
                    drawStep();
                } else if (stroke != -2) {
                    //笔画进度出错,设置为可用笔画
                    if (drawStorke > stroke) {
                        drawStorke = stroke;
                    }
                    if (drawStorke < stroke - 1) {
                        drawStorke = stroke;
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                inTouch = false;
//                stroke = isInsideStroke(touchPath);
//                //int t = isInsideStroke(new Point((int) touchX, (int) touchY));
//                System.out.println("当前触摸笔画 ---- >" + stroke);
//                if (drawStorke + 1 == stroke) {
//                    //下一笔
//                    drawStorke = stroke;
//                    drawStep();
//                }
                break;
        }
        invalidate();
        return true;
    }

    //画田字格
    private void drawGrid(Canvas canvas) {
        //边框
        canvas.drawRect(new Rect(2, 2, width - 2, height - 2), mGridPaint);
        //实线
        canvas.drawLine(0, height / 2, width, height / 2, mGridPaint);
        canvas.drawLine(width / 2, 0, width / 2, height, mGridPaint);
        //虚线
        canvas.drawLine(0, 0, width, height, mDashPaint);
        canvas.drawLine(0, height, width, 0, mDashPaint);
    }

    private void drawStep() {
        System.out.println("=======================");
        System.out.println("drawStep()");
        System.out.println("drawStorke = " + drawStorke);
        System.out.println("stepIdx = " + stepIdx);
        System.out.println("step = " + step);
        System.out.println("touchX = " + touchX);
        System.out.println("touchY = " + touchY);

        if (drawStorke < 0) {
            return;
        }

        if (drawStorke >= mFillData.size()) {
            return;
        }

        if (!drawFinishStorke.contains(-1)) {
            drawFinishStorke.add(-1);
        }

        if (!drawFinishStorke.contains(drawStorke - 1)) {
            //上一笔没有画完
            return;
        }

        int index = stepIdx + step;
        //单笔画总点数
        int strokeTotalPoint = mFillData.get(drawStorke).size();
        //一般情况下最后末尾一点自动填充
        if (index < strokeTotalPoint * 0.9) {
            //防止绘制进度超过手指范围
            List<Point> points = WritingUtil.splitPoints(mFillData.get(drawStorke), (int) (stepIdx - step * 1.5), (int) (stepIdx + step * 1.5));
            Path drawPath = WritingUtil.createPathByPoint(points);
            Region region = WritingUtil.pathToRegion(drawPath);

            if (index > 50 && !region.contains((int) touchX, (int) touchY)) {
                //index 小不用判断,用户手指一般不会从0点开始滑动,容错
                return;
            }

            //笔画起点到手指当前距离
            points = WritingUtil.splitPoints(mFillData.get(drawStorke), 0, index);

            stepIdx += step;

            //画触摸过的区域
            for (int j = 0; j < points.size() - 1; j++) {
                Point p = points.get(j);
                p = scalePoint(p);
                Point nextP = points.get(j + 1);
                nextP = scalePoint(nextP);
                touchCanvas.drawLine(p.x, p.y, nextP.x, nextP.y, mFillPaint);
            }
        } else {
            if (!drawFinishStorke.contains(drawStorke)) {
                drawFinishStorke.add(drawStorke);
            }
            //末尾自动填充
            List<Point> points = mFillData.get(drawStorke);
            for (int j = 0; j < points.size() - 1; j++) {
                Point p = points.get(j);
                p = scalePoint(p);
                Point nextP = points.get(j + 1);
                nextP = scalePoint(nextP);
                touchCanvas.drawLine(p.x, p.y, nextP.x, nextP.y, mFillPaint);
            }
            //重置进度
            stepIdx = 0;
        }
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            invalidate();
        }
    };

    /**
     * 画轮廓
     */
    private void drawOutline(Canvas canvas) {
        try {
            for (int i = 0; i < mFrameData.size(); i++) {
                Path path = new Path();
                List<Point> points = mFrameData.get(i);
                canvas.translate(0, 0);
                for (int j = 0; j < points.size(); j++) {
                    Point point = points.get(j);
                    point = scalePoint(point);
                    if (j == 0) {
                        path.moveTo(point.x, point.y);
                    } else {
                        path.lineTo(point.x, point.y);
                    }
                }
                path.close();
                canvas.drawPath(path, mOutlinePaint);
                //添加缓存
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void initData() {
        //init path frame
        paths.clear();
        for (int i = 0; i < mFrameData.size(); i++) {
            Path path = new Path();
            List<Point> points = mFrameData.get(i);
            for (int j = 0; j < points.size(); j++) {
                Point point = points.get(j);
                point = scalePoint(point);
                if (j == 0) {
                    path.moveTo(point.x, point.y);
                } else {
                    path.lineTo(point.x, point.y);
                }
            }
            path.close();
            paths.add(path);
            //添加缓存
        }
        //regionList
        RectF bounds = new RectF();
        for (int i = 0; i < paths.size(); i++) {
            bounds.setEmpty();
            paths.get(i).computeBounds(bounds, true);
            Region region = new Region();
            region.setPath(paths.get(i), new Region((int) bounds.left, (int) bounds.top, (int) bounds.right, (int) bounds.bottom));
            regionList.add(region);
        }
    }

    /**
     * 判断某一个坐标在哪一个笔画中
     *
     * @param point 坐标点
     * @return 笔画
     */
    private int isInsideStroke(Point point) {
        //笔画重叠会找到多个
        List<Integer> strokes = new ArrayList<>();
        for (int i = 0; i < paths.size(); i++) {
            Region region = regionList.get(i);
            //判断关键点是否在某一笔画中
            if (region.contains(point.x, point.y)) {
                strokes.add(i);
            }
        }

        if (strokes.contains(drawStorke)) {
            return drawStorke;
        } else if (strokes.size() != 0) {
            return strokes.get(0);
        }
        return -2;
    }

    /**
     * 判断当前path 在哪一个笔画中
     *
     * @param p 路径
     * @return 笔画数
     */
    private int isInsideStroke(Path p) {
        //取出所有笔画
        PathMeasure measure = new PathMeasure(p, true);
        float len = measure.getLength();
        if (len < 50) {
            //触摸太短
            return -2;
        }
        for (int i = 0; i < paths.size(); i++) {
            Region region = regionList.get(i);
            //判断关键点是否在某一笔画中
            List<Point> points = getPointInPath(p, 40);
            int containCount = 0;
            for (int j = 0; j < points.size(); j++) {
                Point point = points.get(j);
                if (!region.contains(point.x, point.y)) {
                    if (containCount == 0) {
                        continue;
                    } else {
                        break;
                    }
                } else {
                    containCount++;
                }
                if (containCount > 35) {
                    //相似度很高
                    return i;
                }
                if (j == points.size() - 1) {
                    return i;
                }
            }
        }

        return -2;
    }

    private void drawRegion(Canvas canvas, Region rgn, Paint paint) {
        RegionIterator iter = new RegionIterator(rgn);
        Rect r = new Rect();
        while (iter.next(r)) {
            int c = Color.rgb(random(), random(), random());
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(c);
            canvas.drawRect(r, paint);
        }
    }

    private void drawRegionIndex(Canvas canvas, Region region, Paint paint, int x, int y) {
        if (!region.contains(x, y)) {
            return;
        }
        RegionIterator iter = new RegionIterator(region);
        Rect r = new Rect();
        int idx = 0;
        while (iter.next(r)) {
            if (r.contains(x, y)) {
                regionIndex = idx;
                break;
            } else {
                //int c = Color.rgb(random(), random(), random());
                //paint.setColor(c);
                canvas.drawRect(r, paint);
            }
            idx++;
        }
    }

    private int random() {
        Random random = new Random();
        return random.nextInt(200);
    }

    //当前画线
    private int drawStorke = -1;

    /**
     * 画某一笔
     *
     * @param canvas 画布
     * @param storke 笔数
     */
    private void drawStorke(Canvas canvas, int storke) {
        for (int i = 0; i <= storke && i < mFillData.size(); i++) {
            List<Point> points = mFillData.get(i);
            for (int j = 0; j < points.size() - 1; j++) {
                Point p = points.get(j);
                p = scalePoint(p);
                Point nextP = points.get(j + 1);
                nextP = scalePoint(nextP);
                canvas.drawLine(p.x, p.y, nextP.x, nextP.y, mFillPaint);
            }
        }
    }

    /**
     * 获取path中的所有点
     *
     * @param p    路径
     * @param step 间隔
     * @return
     */
    private List<Point> getPointInPath(Path p, int step) {
        List<Point> list = new ArrayList<>();
        PathMeasure measure = new PathMeasure(p, false);
        float length = measure.getLength();
        float distance = 0f;
        float speed = length / step;
        int counter = 0;
        float[] aCoordinates = new float[2];
        while ((distance < length) && (counter < step)) {
            // get point from the path
            measure.getPosTan(distance, aCoordinates, null);
            Point point = new Point((int) aCoordinates[0], (int) aCoordinates[1]);
            list.add(point);
            counter++;
            distance = distance + speed;
        }
        return list;
    }

    /**
     * 填充
     */
    private void fillStroke(Canvas canvas) {
        for (int i = 0; i < mStrokeStep && i < mFillData.size(); i++) {
            List<Point> points = mFillData.get(i);
            if (i == mStrokeStep - 1) {
                //最后一笔每次步进10
                for (int j = 0; j <= mFillMaxStep && j < points.size() - 1; j++) {
                    Point p = points.get(j);
                    p = scalePoint(p);
                    Point nextP = points.get(j + 1);
                    nextP = scalePoint(nextP);
                    canvas.drawLine(p.x, p.y, nextP.x, nextP.y, mFillPaint);
                }
                if (mFillMaxStep == points.size()) {
                    //单笔顺画完
                    mStrokeStep++;
                    mFillMaxStep = 10;
                } else if (mFillMaxStep > points.size()) {
                    //单笔顺画完
                    for (int j = mFillMaxStep - 10; j < points.size() - 1; j++) {
                        Point point = points.get(j);
                        point = scalePoint(point);
                        Point nextPoint = points.get(j + 1);
                        nextPoint = scalePoint(nextPoint);
                        canvas.drawLine(point.x, point.y, nextPoint.x, nextPoint.y, mFillPaint);
                    }
                    mStrokeStep++;
                    mFillMaxStep = 10;
                } else {
                    //步进10
                    mFillMaxStep += 10;
                }
                //最后一笔延迟,产生动画效果
                handler.removeCallbacksAndMessages(null);
                handler.sendEmptyMessageDelayed(1, mDrawDelay);
            } else if (i <= mStrokeStep) {
                //非最后一笔,直接全部填充,无需延迟动画
                for (int j = 0; j < points.size() - 1; j++) {
                    Point p = points.get(j);
                    p = scalePoint(p);
                    Point nextP = points.get(j + 1);
                    nextP = scalePoint(nextP);
                    canvas.drawLine(p.x, p.y, nextP.x, nextP.y, mFillPaint);
                }
            }
        }
    }

    /**
     * 缩放原数据坐标到布局大小
     */
    private Point scalePoint(Point point) {
        Point p = new Point();
        //760 是原数据默认宽高
        p.x = (int) (point.x / (760f / width));
        p.y = (int) (point.y / (760f / height));
        return p;
    }
}