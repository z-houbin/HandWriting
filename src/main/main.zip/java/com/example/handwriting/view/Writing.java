//package com.example.handwriting.view;
//
//import android.graphics.Canvas;
//
//import android.graphics.Canvas;
//import android.graphics.Paint;
//import android.graphics.Path;
//import android.graphics.Path.FillType;
//import android.graphics.Point;
//import android.graphics.Rect;
//
//import com.wiseman.writing.ConstValue;
//
//import java.util.ArrayList;
//import java.util.List;
//
//class Writing
//        implements ConstValue {
//    private Canvas mCanvas;
//    boolean mIsActive;
//    boolean mIsCharComplete;
//    boolean mIsStrokeComplete;
//    private Paint mPaint;
//    int mPosTolerance = 0;
//    int mStep = 4;
//    int mStepIdx;
//    private StrokeData mStroke;
//    int mStrokeIdx;
//    private List<StrokeData> mStrokeList;
//    final StrokeView mView;
//
//    public Writing(StrokeView paramStrokeView) {
//        this.mView = paramStrokeView;
//        reset();
//    }
//
//    private void drawStep() {
//        ArrayList localArrayList1 = this.mStroke.m_posList;
//        ArrayList localArrayList2 = this.mStroke.m_negList;
//        Path localPath = new Path();
//        int i = this.mStepIdx + this.mStep;
//        if (i > -1 + localArrayList1.size())
//            i = -1 + localArrayList1.size();
//        localPath.addPath(Util.createPathByPoints(localArrayList1, 0, i, null));
//        localPath.addPath(Util.createPathByPoints(localArrayList2, 0, i, null));
//        Point localPoint = (Point) localArrayList1.get(i);
//        localPath.lineTo(localPoint.x, localPoint.y);
//        localPath.setFillType(Path.FillType.EVEN_ODD);
//        this.mCanvas.drawPath(localPath, this.mPaint);
//        this.mView.postInvalidate();
//        this.mStepIdx += this.mStep;
//        if (this.mStepIdx > -1 + localArrayList1.size())
//            this.mIsStrokeComplete = true;
//    }
//
//    private boolean ptInStroke(Point paramPoint) {
//        ArrayList localArrayList1 = this.mStroke.m_posList;
//        ArrayList localArrayList2 = this.mStroke.m_negList;
//        Point localPoint1 = new Point();
//        Point localPoint2 = new Point();
//        if (this.mStepIdx > -1 + localArrayList1.size())
//            return false;
//        localPoint1.set(((Point) localArrayList1.get(this.mStepIdx)).x, ((Point) localArrayList1.get(this.mStepIdx)).y);
//        localPoint2.set(((Point) localArrayList1.get(this.mStepIdx)).x, ((Point) localArrayList1.get(this.mStepIdx)).y);
//        for (int i = 0; ; i++) {
//            int j;
//            if (i < this.mStep) {
//                j = i + this.mStepIdx;
//                if (j <= -1 + localArrayList1.size()) ;
//            } else {
//                Rect localRect = new Rect(localPoint1.x, localPoint1.y, localPoint2.x, localPoint2.y);
//                localRect.left -= this.mPosTolerance;
//                localRect.top -= this.mPosTolerance;
//                localRect.right += this.mPosTolerance;
//                localRect.bottom += this.mPosTolerance;
//                return Util.ptInRect(paramPoint, localRect);
//            }
//            Util.checkBoundValue(localPoint1, localPoint2, (Point) localArrayList1.get(j));
//            Util.checkBoundValue(localPoint1, localPoint2, (Point) localArrayList2.get(j));
//        }
//    }
//
//    public void handleActionDown(Point paramPoint) {
//        if (ptInStroke(paramPoint)) {
//            drawStep();
//            if (!this.mIsActive)
//                this.mIsActive = true;
//        }
//    }
//
//    public void handleActionMove(Point paramPoint) {
//        if (!this.mIsActive) ;
//        do
//            return;
//        while ((this.mIsStrokeComplete) || (!ptInStroke(paramPoint)));
//        drawStep();
//    }
//
//    public void handleActionUp(Point paramPoint) {
//        if (!this.mIsActive) ;
//        while (true) {
//            return;
//            if (this.mIsStrokeComplete) {
//                this.mStrokeIdx = (1 + this.mStrokeIdx);
//                if (this.mStrokeIdx < this.mStrokeList.size()) {
//                    this.mStroke = ((StrokeData) this.mStrokeList.get(this.mStrokeIdx));
//                    this.mIsStrokeComplete = false;
//                    this.mStepIdx = 0;
//                    if (this.mView.mIsShowGuide)
//                        Util.drawGuideLine(this.mCanvas, this.mStroke);
//                    this.mView.postInvalidate();
//                    return;
//                }
//                this.mIsCharComplete = true;
//                this.mStroke = ((StrokeData) this.mStrokeList.get(0));
//                return;
//            }
//            if (this.mStepIdx < 0.85D * this.mStroke.m_posList.size())
//                continue;
//            while (!this.mIsStrokeComplete)
//                drawStep();
//        }
//    }
//
//    boolean isCharComplete() {
//        return this.mIsCharComplete;
//    }
//
//    public boolean isStartWrite(Point paramPoint) {
//        ArrayList localArrayList1 = ((StrokeData) this.mStrokeList.get(0)).m_posList;
//        ArrayList localArrayList2 = ((StrokeData) this.mStrokeList.get(0)).m_negList;
//        Point localPoint1 = new Point();
//        Point localPoint2 = new Point();
//        localPoint1.set(((Point) localArrayList1.get(0)).x, ((Point) localArrayList1.get(0)).y);
//        localPoint2.set(((Point) localArrayList1.get(0)).x, ((Point) localArrayList1.get(0)).y);
//        for (int i = 0; ; i++) {
//            int j;
//            if (i < this.mStep) {
//                j = i;
//                if (j <= -1 + localArrayList1.size()) ;
//            } else {
//                Rect localRect = new Rect(localPoint1.x, localPoint1.y, localPoint2.x, localPoint2.y);
//                localRect.left -= this.mPosTolerance;
//                localRect.top -= this.mPosTolerance;
//                localRect.right += this.mPosTolerance;
//                localRect.bottom += this.mPosTolerance;
//                return Util.ptInRect(paramPoint, localRect);
//            }
//            Util.checkBoundValue(localPoint1, localPoint2, (Point) localArrayList1.get(j));
//            Util.checkBoundValue(localPoint1, localPoint2, (Point) localArrayList2.get(j));
//        }
//    }
//
//    void reset() {
//        this.mIsActive = false;
//        this.mStrokeIdx = 0;
//        this.mStepIdx = 0;
//        this.mIsStrokeComplete = false;
//        this.mIsCharComplete = false;
//    }
//
//    public void setData(List<StrokeData> paramList, Canvas paramCanvas, Paint paramPaint) {
//        this.mStrokeList = paramList;
//        this.mStroke = ((StrokeData) this.mStrokeList.get(0));
//        this.mCanvas = paramCanvas;
//        this.mPaint = paramPaint;
//    }
//
//    public void setWritingSensivity(int paramInt) {
//        this.mPosTolerance = (10 * (paramInt + 1));
//        this.mStep = (4 * (1 + paramInt / 2));
//    }
//}