package com.example.handwriting.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.RegionIterator;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.example.handwriting.util.WritingUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//动画效果不够连贯
public class HandwritingView_old extends View {
    private Paint mOutlinePaint, mFillPaint, mTouchPaint;
    private List<List<Point>> mFrameData = new ArrayList<>();
    private List<List<Point>> mFillData = new ArrayList<>();
    private Path path = new Path();
    //控件宽高
    private int width = 0, height = 0;
    //当前绘制笔画数
    private int mStrokeStep = 1;
    //单笔最大填充数
    private int mFillMaxStep;
    //动画延迟时间
    private int mDrawDelay = 50;

    private Bitmap touchBitmap;

    private Canvas touchCanvas;


    private int regionIndex = 0;

    private boolean inTouch = false;
    //不规则范围
    private List<Region> regionList = new ArrayList<>();
    //已经画完的笔画
    private List<Integer> drawFinishStorke = new ArrayList<>();

    public HandwritingView_old(Context context) {
        super(context);
        init();
    }

    public HandwritingView_old(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public HandwritingView_old(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        mOutlinePaint = new Paint();
        mOutlinePaint.setColor(Color.GRAY);
        mOutlinePaint.setStrokeJoin(Paint.Join.ROUND);
        mOutlinePaint.setStrokeCap(Paint.Cap.ROUND);
        mOutlinePaint.setAntiAlias(true);
        //Paint.Style.FILL_AND_STROKE 为实心
        mOutlinePaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mOutlinePaint.setStrokeWidth(15);

        mFillPaint = new Paint();
        mFillPaint.setColor(Color.RED);
        mFillPaint.setStrokeJoin(Paint.Join.ROUND);
        mFillPaint.setStrokeCap(Paint.Cap.ROUND);
        mFillPaint.setAntiAlias(true);
        mFillPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mFillPaint.setStrokeWidth(10);

        mTouchPaint = new Paint();
        mTouchPaint.setColor(Color.BLUE);
        mTouchPaint.setAntiAlias(true);
        mTouchPaint.setStyle(Paint.Style.STROKE);
        mTouchPaint.setStrokeWidth(2);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        width = getMeasuredWidth();
        height = getMeasuredHeight();

        if (touchBitmap == null) {
            touchBitmap = Bitmap.createBitmap(getMeasuredWidth(), getMeasuredHeight(), Bitmap.Config.ARGB_8888);
            touchCanvas = new Canvas(touchBitmap);
        }
    }

    public void setText(String text) throws Exception {
        drawFinishStorke.clear();
        drawStorke = -1;
        mStrokeStep = 1;
        mFillMaxStep = 10;
        paths.clear();
        regionList.clear();
        //JSON 数据解析
        String assetsName = WritingUtil.urlEncode(text);
        String jsonData = WritingUtil.getAssestFileContent(getContext(), assetsName);
        mFrameData = WritingUtil.parseJsonFrame(jsonData);
        mFillData = WritingUtil.parseJsonFill(jsonData);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //画边框背景
        drawOutline(canvas);
        if (regionList.size() == 0) {
            initData();
        }
        //填充
        //fillStroke(canvas);

        //canvas.drawBitmap(touchBitmap, 0, 0, mTouchPaint);
        //canvas.drawPath(touchPath, mTouchPaint);

        if (drawStorke != -1) {
            boolean hasDraw = drawFinishStorke.contains(drawStorke);
            if (inTouch && !hasDraw) {
                if (!drawFinishStorke.contains(drawStorke)) {
                    drawStorke(canvas, drawStorke - 1);
                    try {
                        drawRegionIndex(canvas, regionList.get(drawStorke), mFillPaint, (int) touchX, (int) touchY);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {
                drawStorke(canvas, drawStorke);
                if (!drawFinishStorke.contains(drawStorke)) {
                    drawFinishStorke.add(drawStorke);
                }
            }
            drawSingleStorke = false;
        }

        mOutlinePaint.setColor(Color.DKGRAY);
    }

    private Path touchPath = new Path();
    private boolean isTouch = false;
    private float downX, downY, touchX, touchY;

    private List<Path> paths = new ArrayList<>();

    private int moveCount = 0;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX(), y = event.getY();
        touchX = event.getX();
        touchY = event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                moveCount = 0;
                touchPath.reset();
                touchPath.moveTo(x, y);
                downX = x;
                downY = y;
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                inTouch = true;
                touchPath.lineTo(x, y);
                if (true) {
                    int t = isInsideStorke(touchPath);
                    System.out.println("touch 包含 ---- >" + t);
                    if (drawStorke + 1 == t) {
                        //下一笔
                        drawStorke(t);
                    }
                }

                invalidate();
                moveCount++;
                break;
            case MotionEvent.ACTION_UP:
                touch_up(x, y);
                inTouch = false;
            {
                int t = isInsideStorke(touchPath);
                System.out.println("包含 ---- >" + t);
                if (drawStorke + 1 == t) {
                    //下一笔
                    drawStorke(t);
                }
            }
            invalidate();
            break;
        }
        return true;
    }

    private static final float TOUCH_TOLERANCE = 4;

    private void touch_start(float x, float y) {
        touchPath.reset();
        touchPath.moveTo(x, y);
        downX = x;
        downY = y;
    }

    private void touch_move(float x, float y) {
        float dx = Math.abs(x - downX);
        float dy = Math.abs(y - downY);
        if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
            touchPath.quadTo(downX, downY, (x + downX) / 2, (y + downY) / 2);
            downX = x;
            downY = y;
        }
    }

    private void touch_up(float x, float y) {
        touchPath.lineTo(x, y);
        touchCanvas.drawPath(touchPath, mTouchPaint);
        touchPath.reset();
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            invalidate();
        }
    };

    /**
     * 画轮廓
     */
    private void drawOutline(Canvas canvas) {
        try {
            for (int i = 0; i < mFrameData.size(); i++) {
                Path path = new Path();
                List<Point> points = mFrameData.get(i);
                canvas.translate(0, 0);
                for (int j = 0; j < points.size(); j++) {
                    Point point = points.get(j);
                    point = scalePoint(point);
                    if (j == 0) {
                        path.moveTo(point.x, point.y);
                    } else {
                        path.lineTo(point.x, point.y);
                    }
                }
                path.close();
                canvas.drawPath(path, mOutlinePaint);
                //添加缓存
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Region r;

    private void initData() {
        //initPath
        paths.clear();
        for (int i = 0; i < mFillData.size(); i++) {
            List<Point> points = mFillData.get(i);
            Path path = new Path();
            for (int j = 0; j < points.size() - 1; j++) {
                Point p = points.get(j);
                p = scalePoint(p);
                if (j == 0) {
                    path.moveTo(p.x, p.y);
                } else {
                    path.lineTo(p.x, p.y);
                }
            }
            path.close();
            paths.add(path);
        }
        //initpath frame
        paths.clear();
        for (int i = 0; i < mFrameData.size(); i++) {
            Path path = new Path();
            List<Point> points = mFrameData.get(i);
            for (int j = 0; j < points.size(); j++) {
                Point point = points.get(j);
                point = scalePoint(point);
                if (j == 0) {
                    path.moveTo(point.x, point.y);
                } else {
                    path.lineTo(point.x, point.y);
                }
            }
            path.close();
            paths.add(path);
            //添加缓存
        }
        //regionList
        RectF bounds = new RectF();
        for (int i = 0; i < paths.size(); i++) {
            bounds.setEmpty();
            paths.get(i).computeBounds(bounds, true);
            Region region = new Region();
            region.setPath(paths.get(i), new Region((int) bounds.left, (int) bounds.top, (int) bounds.right, (int) bounds.bottom));
            regionList.add(region);
        }
    }

    private int isInsideStorke(Path p) {
        RectF bounds = new RectF();
        //取出所有笔画
        PathMeasure measure = new PathMeasure(p, true);
        float len = measure.getLength();
        if (len < 50) {
            //触摸太短
            return -1;
        }

        for (int i = 0; i < paths.size(); i++) {
            Region region = regionList.get(i);
            //判断关键点是否在某一笔画中
            if (r == null) {
                r = new Region(region);
            }

            List<Point> points = getPointInPath(p, 40);
            int containCount = 0;
            in:
            for (int j = 0; j < points.size(); j++) {
                Point point = points.get(j);
                if (!region.contains(point.x, point.y) && containCount == 0) {
                    break in;
                } else {
                    containCount++;
                }
                if (containCount > 40 / 2) {
                    return i;
                }
                if (j == points.size() - 1) {
                    return i;
                }
            }
        }

        return -1;
    }

    private void drawRegion(Canvas canvas, Region rgn, Paint paint) {
        RegionIterator iter = new RegionIterator(rgn);
        Rect r = new Rect();
        while (iter.next(r)) {
            int c = Color.rgb(random(), random(), random());
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(c);
            canvas.drawRect(r, paint);
        }
    }

    private void drawRegionIndex(Canvas canvas, Region region, Paint paint, int x, int y) {
        if (!region.contains(x, y)) {
            return;
        }
        RegionIterator iter = new RegionIterator(region);
        Rect r = new Rect();
        int idx = 0;
        while (iter.next(r)) {
            if (r.contains(x, y)) {
                regionIndex = idx;
                break;
            } else {
                //int c = Color.rgb(random(), random(), random());
                //paint.setColor(c);
                canvas.drawRect(r, paint);
            }
            idx++;
        }
    }

    private int random() {
        Random random = new Random();
        return random.nextInt(200);
    }


    //画一笔
    private boolean drawSingleStorke = false;
    //当前画线
    private int drawStorke = -1;
    //下一笔
    private int nextStorke = 0;

    /**
     * 画某一笔画
     *
     * @param storke 指定笔画,0开始
     */
    public void drawStorke(int storke) {
        if (storke < 0) {
            System.err.println("笔画数错误");
        } else if (storke > mFillData.size() - 1) {
            System.err.println("笔画数错误");
        } else {
            drawSingleStorke = true;
            drawStorke = storke;
            invalidate();
        }
    }

    private int lastStorke = -1;

    /**
     * 画某一笔
     *
     * @param canvas 画布
     * @param storke 笔数
     */
    private void drawStorke(Canvas canvas, int storke) {
        lastStorke = storke;
        for (int i = 0; i <= storke && i < mFillData.size(); i++) {
            List<Point> points = mFillData.get(i);
            for (int j = 0; j < points.size() - 1; j++) {
                Point p = points.get(j);
                p = scalePoint(p);
                Point nextP = points.get(j + 1);
                nextP = scalePoint(nextP);
                canvas.drawLine(p.x, p.y, nextP.x, nextP.y, mFillPaint);
            }
        }
    }

    /**
     * 获取path中的所有点
     *
     * @param p    路径
     * @param step 间隔
     * @return
     */
    private List<Point> getPointInPath(Path p, int step) {
        List<Point> list = new ArrayList<>();
        PathMeasure measure = new PathMeasure(p, false);
        float length = measure.getLength();
        float distance = 0f;
        float speed = length / step;
        int counter = 0;
        float[] aCoordinates = new float[2];
        while ((distance < length) && (counter < step)) {
            // get point from the path
            measure.getPosTan(distance, aCoordinates, null);
            Point point = new Point((int) aCoordinates[0], (int) aCoordinates[1]);
            list.add(point);
            counter++;
            distance = distance + speed;
        }
        return list;
    }

    /**
     * 填充
     */
    private void fillStroke(Canvas canvas) {
        for (int i = 0; i < mStrokeStep && i < mFillData.size(); i++) {
            List<Point> points = mFillData.get(i);

            if (i == mStrokeStep - 1) {
                Path pp = new Path();
                List<Point> ps = mFrameData.get(i);
                canvas.translate(0, 0);
                for (int j = 0; j < ps.size(); j++) {
                    Point point = ps.get(j);
                    point = scalePoint(point);
                    if (j == 0) {
                        pp.moveTo(point.x, point.y);
                    } else {
                        pp.lineTo(point.x, point.y);
                    }
                }
                pp.close();
                mOutlinePaint.setColor(Color.RED);
                canvas.drawPath(pp, mOutlinePaint);

                //最后一笔每次步进10
                for (int j = 0; j <= mFillMaxStep && j < points.size() - 1; j++) {
                    Point p = points.get(j);
                    p = scalePoint(p);
                    Point nextP = points.get(j + 1);
                    nextP = scalePoint(nextP);
                    canvas.drawLine(p.x, p.y, nextP.x, nextP.y, mOutlinePaint);
                }
                if (mFillMaxStep == points.size()) {
                    //单笔顺画完
                    mStrokeStep++;
                    mFillMaxStep = 10;
                } else if (mFillMaxStep > points.size()) {
                    //单笔顺画完
                    for (int j = mFillMaxStep - 10; j < points.size() - 1; j++) {
                        Point point = points.get(j);
                        point = scalePoint(point);
                        Point nextPoint = points.get(j + 1);
                        nextPoint = scalePoint(nextPoint);
                        canvas.drawLine(point.x, point.y, nextPoint.x, nextPoint.y, mFillPaint);
                    }
                    mStrokeStep++;
                    mFillMaxStep = 10;
                } else {
                    //步进10
                    mFillMaxStep += 10;
                }
                //最后一笔延迟,产生动画效果
                handler.removeCallbacksAndMessages(null);
                handler.sendEmptyMessageDelayed(1, mDrawDelay);
            } else if (i <= mStrokeStep) {
                //非最后一笔,直接全部填充,无需延迟动画
                for (int j = 0; j < points.size() - 1; j++) {
                    Point p = points.get(j);
                    p = scalePoint(p);
                    Point nextP = points.get(j + 1);
                    nextP = scalePoint(nextP);
                    canvas.drawLine(p.x, p.y, nextP.x, nextP.y, mFillPaint);
                }
                //
//                Path pp = new Path();
//                List<Point> ps = mFrameData.get(i);
//                canvas.translate(0, 0);
//                for (int j = 0; j < ps.size(); j++) {
//                    Point point = ps.get(j);
//                    point = scalePoint(point);
//                    if (j == 0) {
//                        pp.moveTo(point.x, point.y);
//                    } else {
//                        pp.lineTo(point.x, point.y);
//                    }
//                    if(j%6==0){
//                        //canvas.drawPoint(point.x,point.y,mTouchPaint);
//                    }
//                }
//                pp.close();
//                mOutlinePaint.setColor(Color.RED);
                //canvas.drawPath(pp, mOutlinePaint);
            }
        }
    }

    private boolean op = false;

    public void op() {
        op = true;

    }

    /**
     * 缩放原数据坐标到布局大小
     */
    private Point scalePoint(Point point) {
        Point p = new Point();
        //760 是原数据默认宽高
        p.x = (int) (point.x / (760f / width));
        p.y = (int) (point.y / (760f / height));
        return p;
    }
}