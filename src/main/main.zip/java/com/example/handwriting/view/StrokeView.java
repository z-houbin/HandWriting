//package com.example.handwriting.view;
//
//import android.content.Context;
//import android.graphics.Bitmap;
//import android.graphics.Canvas;
//import android.graphics.Paint;
//import android.graphics.Path;
//import android.graphics.Point;
//import android.graphics.Rect;
//import android.util.AttributeSet;
//import android.util.Log;
//import android.view.MotionEvent;
//import android.view.View;
//import android.view.ViewConfiguration;
//
//import com.wiseman.writing.ConstValue;
//
//import java.util.Iterator;
//import java.util.List;
//
//public class StrokeView extends View
//        implements ConstValue {
//    boolean mAlwaysInTapRegion = false;
//    private BSJavaApi mBSObj = null;
//    private char mCharacter = 65534;
//    private MotionEvent mCurrentDownEvent;
//    private Bitmap mDemoBitmap = null;
//    private Canvas mDemoCanvas = null;
//    private DemoThread mDemoThread = null;
//    private Paint mFillBlackPaint = null;
//    private Paint mFillWhitePaint = null;
//    private int mFontSize = -1;
//    boolean mIsShowGuide = true;
//    Listener mListener = null;
//    private List<StrokeData> mStrokeDataList = null;
//    private Paint mStrokeGrayPaint = null;
//    private StrokeMode mStrokeMode = StrokeMode.demo;
//    private int mStrokeNum = 0;
//    private int mTouchSlopSquare;
//    private Bitmap mWriteBitmap = null;
//    private Canvas mWriteCanvas = null;
//    private int mWrite_x = 0;
//    private int mWrite_y = 0;
//    private Writing mWriting;
//    private int m_DemoDelay = 30;
//    private int m_DemoStep = 2;
//
//    public StrokeView(Context paramContext) {
//        super(paramContext);
//        defInit();
//    }
//
//    public StrokeView(Context paramContext, int paramInt, StrokeMode paramStrokeMode) {
//        super(paramContext, null);
//        if (!isInEditMode())
//            this.mBSObj = new BSJavaApi(getContext(), 1, 3);
//        init();
//        this.mStrokeMode = paramStrokeMode;
//    }
//
//    public StrokeView(Context paramContext, AttributeSet paramAttributeSet) {
//        super(paramContext, paramAttributeSet);
//        defInit();
//    }
//
//    public StrokeView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
//        super(paramContext, paramAttributeSet, paramInt);
//        defInit();
//    }
//
//    private void init() {
//        this.mWrite_x = 0;
//        this.mWrite_y = 0;
//        this.mFillWhitePaint = new Paint();
//        this.mFillWhitePaint.setColor(-1);
//        this.mFillWhitePaint.setStyle(Paint.Style.FILL);
//        this.mStrokeGrayPaint = new Paint();
//        this.mStrokeGrayPaint.setColor(-7829368);
//        this.mStrokeGrayPaint.setStyle(Paint.Style.STROKE);
//        this.mStrokeGrayPaint.setAntiAlias(true);
//        this.mFillBlackPaint = new Paint();
//        this.mFillBlackPaint.setColor(-16777216);
//        this.mFillBlackPaint.setStyle(Paint.Style.FILL);
//        this.mFillBlackPaint.setAntiAlias(true);
//        this.mDemoCanvas = new Canvas();
//        this.mWriteCanvas = new Canvas();
//        this.mWriting = new Writing(this);
//        int i = ViewConfiguration.get(getContext()).getScaledTouchSlop();
//        this.mTouchSlopSquare = (i * i);
//    }
//
//    private void setFontSize(int paramInt) {
//        if (this.mFontSize == paramInt)
//            return;
//        this.mWriting.setWritingSensivity(3);
//        this.mFontSize = paramInt;
//        if (this.mDemoBitmap != null)
//            this.mDemoBitmap.recycle();
//        this.mDemoBitmap = Bitmap.createBitmap(paramInt, paramInt, Bitmap.Config.ARGB_8888);
//        this.mDemoCanvas.setBitmap(this.mDemoBitmap);
//        if (this.mWriteBitmap != null)
//            this.mWriteBitmap.recycle();
//        this.mWriteBitmap = Bitmap.createBitmap(paramInt, paramInt, Bitmap.Config.ARGB_8888);
//        this.mWriteCanvas.setBitmap(this.mWriteBitmap);
//    }
//
//    public void clear() {
//        if (this.mDemoBitmap != null) {
//            this.mDemoBitmap.recycle();
//            this.mDemoBitmap = null;
//        }
//        if (this.mWriteBitmap != null) {
//            this.mWriteBitmap.recycle();
//            this.mWriteBitmap = null;
//        }
//        this.mStrokeDataList.clear();
//        System.gc();
//    }
//
//    void defInit() {
//        if (!isInEditMode())
//            this.mBSObj = new BSJavaApi(getContext(), 1, 3);
//        init();
//    }
//
//    public void demoChar() {
//        if ((this.mDemoThread != null) && (this.mDemoThread.isAlive()))
//            return;
//        this.mStrokeMode = StrokeMode.demo;
//        showChar(null, this.mCharacter, this.mFontSize);
//        this.mDemoThread = new DemoThread();
//        this.mDemoThread.start();
//        invalidate();
//    }
//
//    public int getStrokeNum() {
//        return this.mStrokeNum;
//    }
//
//    public boolean hasChar(char paramChar) {
//        if (!this.mBSObj.prepareData(paramChar)) {
//            Log.d("stroke_order", "prepareData() error!");
//            return false;
//        }
//        return true;
//    }
//
//    protected void onDraw(Canvas paramCanvas) {
//        Bitmap localBitmap1 = this.mDemoBitmap;
//        if (localBitmap1 == null)
//            return;
//        int i = (getWidth() - localBitmap1.getWidth()) / 2;
//        int j = (getHeight() - localBitmap1.getHeight()) / 2;
//        this.mWrite_x = i;
//        this.mWrite_y = j;
//        Bitmap localBitmap2;
//        switch (1.
//        $SwitchMap$com$wiseman$writing$utility$StrokeView$StrokeMode[this.mStrokeMode.ordinal()])
//        {
//            default:
//                localBitmap2 = this.mDemoBitmap;
//            case 1:
//            case 2:
//        }
//        while (localBitmap2 != null) {
//            paramCanvas.drawBitmap(localBitmap2, i, j, null);
//            return;
//            localBitmap2 = this.mDemoBitmap;
//            continue;
//            localBitmap2 = this.mWriteBitmap;
//        }
//    }
//
//    public boolean onTouchEvent(MotionEvent paramMotionEvent) {
//        Point localPoint = new Point();
//        localPoint.x = ((int) paramMotionEvent.getX() - this.mWrite_x);
//        localPoint.y = ((int) paramMotionEvent.getY() - this.mWrite_y);
//        if (this.mStrokeMode != StrokeMode.writing)
//            writeChar();
//        switch (paramMotionEvent.getAction()) {
//            default:
//            case 0:
//            case 2:
//            case 1:
//        }
//        do {
//            int i;
//            int j;
//            do {
//                return true;
//                if (this.mWriting.isCharComplete()) {
//                    showChar(null, this.mCharacter, this.mFontSize);
//                    this.mWriting.reset();
//                    invalidate();
//                }
//                this.mWriting.handleActionDown(localPoint);
//                this.mAlwaysInTapRegion = true;
//                this.mCurrentDownEvent = MotionEvent.obtain(paramMotionEvent);
//                return true;
//                this.mWriting.handleActionMove(localPoint);
//                i = (int) (paramMotionEvent.getX() - this.mCurrentDownEvent.getX());
//                j = (int) (paramMotionEvent.getY() - this.mCurrentDownEvent.getY());
//            }
//            while (i * i + j * j <= this.mTouchSlopSquare);
//            this.mAlwaysInTapRegion = false;
//            return true;
//            this.mWriting.handleActionUp(localPoint);
//            if ((!this.mWriting.isCharComplete()) || (this.mListener == null))
//                continue;
//            this.mListener.finishedWriting();
//        }
//        while (!this.mAlwaysInTapRegion);
//        return true;
//    }
//
//    public boolean setChar(char paramChar, int paramInt) {
//        Log.d("stroke_order", "set character:" + String.valueOf(paramChar));
//        if (!this.mBSObj.prepareData(paramChar)) {
//            Log.d("stroke_order", "prepareData() error!");
//            return false;
//        }
//        this.mStrokeNum = this.mBSObj.getStrokeNum();
//        this.mCharacter = paramChar;
//        setFontSize(paramInt);
//        this.mStrokeDataList = this.mBSObj.getCharData(paramInt);
//        this.mWriting.reset();
//        this.mWriting.setData(this.mStrokeDataList, this.mWriteCanvas, this.mFillBlackPaint);
//        return true;
//    }
//
//    public void setDemoSpeed(int paramInt) {
//        this.m_DemoDelay = (10 * (5 - paramInt));
//        if (paramInt > 2)
//            this.m_DemoStep = (paramInt * 2 / 2);
//    }
//
//    public void setListener(Listener paramListener) {
//        this.mListener = paramListener;
//    }
//
//    public void setMode(StrokeMode paramStrokeMode) {
//        this.mStrokeMode = paramStrokeMode;
//    }
//
//    public void setWrtingSensivity(int paramInt) {
//        this.mWriting.setWritingSensivity(paramInt);
//    }
//
//    public void showChar(Canvas paramCanvas, char paramChar, int paramInt) {
//        if ((this.mDemoThread != null) && (this.mDemoThread.isAlive()))
//            this.mDemoThread.interrupt();
//        try {
//            Thread.sleep(50L);
//            if ((this.mCharacter == paramChar) || ((this.mFontSize == paramInt) || (paramCanvas == null)))
//                ;
//            switch (1.
//            $SwitchMap$com$wiseman$writing$utility$StrokeView$StrokeMode[this.mStrokeMode.ordinal()])
//            {
//                default:
//                    paramCanvas = this.mDemoCanvas;
//                    paramCanvas.drawRect(new Rect(0, 0, this.mFontSize, this.mFontSize), this.mFillWhitePaint);
//                    Util.drawMiRect(paramCanvas, new Rect(0, 0, this.mFontSize, this.mFontSize));
//                    Iterator localIterator = this.mStrokeDataList.iterator();
//                    while (localIterator.hasNext())
//                        Util.drawStroke(paramCanvas, (StrokeData) localIterator.next(), this.mStrokeGrayPaint);
//                case 2:
//            }
//        } catch (InterruptedException localInterruptedException) {
//            while (true) {
//                localInterruptedException.printStackTrace();
//                continue;
//                paramCanvas = this.mWriteCanvas;
//            }
//            if ((this.mStrokeMode == StrokeMode.writing) && (this.mIsShowGuide))
//                Util.drawGuideLine(paramCanvas, (StrokeData) this.mStrokeDataList.get(0));
//        }
//    }
//
//    public void showNextStrokeHint(boolean paramBoolean) {
//        this.mIsShowGuide = paramBoolean;
//    }
//
//    public void writeChar() {
//        this.mStrokeMode = StrokeMode.writing;
//        showChar(null, this.mCharacter, this.mFontSize);
//        this.mWriting.reset();
//        this.mWriting.setData(this.mStrokeDataList, this.mWriteCanvas, this.mFillBlackPaint);
//        invalidate();
//    }
//
//    class DemoThread extends Thread {
//        DemoThread() {
//        }
//
//        private void demoStroke(StrokeData paramStrokeData)
//                throws InterruptedException {
//            int i = paramStrokeData.m_posList.size();
//            Path localPath = new Path();
//            int j = 0;
//            while (true) {
//                if ((j >= i) || (interrupted()))
//                    return;
//                int k = j + StrokeView.this.m_DemoStep;
//                localPath.addPath(Util.createPathByPoints(paramStrokeData.m_posList, 0, k, null));
//                localPath.addPath(Util.createPathByPoints(paramStrokeData.m_negList, 0, k, null));
//                if (k > i - 1)
//                    k = i - 1;
//                Point localPoint = (Point) paramStrokeData.m_posList.get(k);
//                localPath.lineTo(localPoint.x, localPoint.y);
//                localPath.setFillType(Path.FillType.EVEN_ODD);
//                StrokeView.this.mDemoCanvas.drawPath(localPath, StrokeView.this.mFillBlackPaint);
//                StrokeView.this.postInvalidate();
//                localPath.rewind();
//                Thread.sleep(StrokeView.this.m_DemoDelay);
//                j += StrokeView.this.m_DemoStep;
//            }
//        }
//
//        public void run() {
//            Iterator localIterator = StrokeView.this.mStrokeDataList.iterator();
//            while (true) {
//                StrokeData localStrokeData;
//                if (localIterator.hasNext()) {
//                    localStrokeData = (StrokeData) localIterator.next();
//                    if (!interrupted()) ;
//                } else {
//                    return;
//                }
//                try {
//                    demoStroke(localStrokeData);
//                } catch (InterruptedException localInterruptedException) {
//                }
//            }
//        }
//    }
//
//    public static abstract interface Listener {
//        public abstract void finishedWriting();
//    }
//
//    private static enum StrokeMode {
//        static {
//            strokeSeq = new StrokeMode("strokeSeq", 2);
//            StrokeMode[] arrayOfStrokeMode = new StrokeMode[3];
//            arrayOfStrokeMode[0] = demo;
//            arrayOfStrokeMode[1] = writing;
//            arrayOfStrokeMode[2] = strokeSeq;
//            $VALUES = arrayOfStrokeMode;
//        }
//    }
//}