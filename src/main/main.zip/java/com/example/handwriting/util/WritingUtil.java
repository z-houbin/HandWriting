package com.example.handwriting.util;

import android.content.Context;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.Region;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class WritingUtil {

    public static int width, height;

    public static String urlEncode(String c) throws Exception {
        String encode = URLEncoder.encode(c, "utf-8");
        encode = encode.replaceAll("%", "");
        return encode.toLowerCase();
    }

    public static String getAssestFileContent(Context context, String name) {
        String json = "";
        try {
            StringBuilder builder = new StringBuilder();
            InputStreamReader streamReader = new InputStreamReader(context.getAssets().open(name), "UTF-8");
            BufferedReader reader = new BufferedReader(streamReader);
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
                builder.append("");
            }
            json = builder.toString();
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return json;
    }

    public static List<List<Point>> parseJsonFrame(String json) {
        List<List<Point>> mFrame = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONObject data = jsonObject.getJSONArray("data").getJSONObject(0);
            JSONArray out = data.getJSONArray("frame");
            for (int i = 0; i < out.length(); i++) {
                List<Point> ps = new ArrayList<>();
                JSONArray frame = out.getJSONArray(i);
                for (int j = 0; j < frame.length(); j++) {
                    JSONArray pointArr = frame.getJSONArray(j);
                    Point p = new Point();
                    p.set(pointArr.getInt(0), pointArr.getInt(1));
                    ps.add(p);
                }
                mFrame.add(ps);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mFrame;
    }

    public static List<List<Point>> parseJsonFill(String json) {
        List<List<Point>> mFrame = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONObject data = jsonObject.getJSONArray("data").getJSONObject(0);
            JSONArray out = data.getJSONArray("fill");
            for (int i = 0; i < out.length(); i++) {
                List<Point> ps = new ArrayList<>();
                JSONArray frame = out.getJSONArray(i);
                for (int j = 0; j < frame.length(); j++) {
                    JSONArray pointArr = frame.getJSONArray(j);
                    Point p = new Point();
                    p.set(pointArr.getInt(0), pointArr.getInt(1));
                    ps.add(p);
                }
                mFrame.add(ps);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mFrame;
    }

    /**
     * 全部
     *
     * @param points
     * @return
     */
    public static Path createPathByPoint(List<Point> points) {
        Path path = new Path();
        for (int i = 0; i < points.size(); i++) {
            Point p = points.get(i);
            p = scalePoint(p);
            if (i == 0) {
                path.moveTo(p.x, p.y);
            } else {
                path.lineTo(p.x, p.y);
            }
        }
        path.close();
        return path;
    }

    public static Region pathToRegion(Path path) {
        RectF bounds = new RectF();
        bounds.setEmpty();
        path.computeBounds(bounds, true);
        Region region = new Region();
        region.setPath(path, new Region((int) bounds.left, (int) bounds.top, (int) bounds.right, (int) bounds.bottom));
        return region;
    }

    /**
     * 区间
     *
     * @param points
     * @param startIndex
     * @param endIndex
     * @return
     */
    public static Path createPathByPoint(List<Point> points, int startIndex, int endIndex) {
        Path path = new Path();
        Point lastP = new Point();
        for (int i = startIndex; i < points.size() && i < endIndex; i++) {
            Point p = points.get(i);
            p = scalePoint(p);
            if (i == startIndex) {
                path.moveTo(p.x, p.y);
            } else {
                path.quadTo(lastP.x, lastP.y, p.x, p.y);
                //path.lineTo(p.x, p.y);
            }
            lastP = p;
        }
        return path;
    }

    public static List<Point> splitPoints(List<Point> points, int startIndex, int endIndex) {
        List<Point> ps = new ArrayList<>();
        if (startIndex < 0) {
            startIndex = 0;
        }
        for (int i = startIndex; i < points.size() && i < endIndex; i++) {
            Point p = points.get(i);
            ps.add(p);
        }
        return ps;
    }

    /**
     * 缩放原数据坐标到布局大小
     */
    public static Point scalePoint(Point point) {
        Point p = new Point();
        //760 是原数据默认宽高
        p.x = (int) (point.x / (760f / width));
        p.y = (int) (point.y / (760f / height));
        return p;
    }

}
